% normally make k = 0.04 and sigma = 1

function [corners] = harris_corner(img, k, sigma)

% Convert image to type double and to grayscale if needed.
% assume the image has already been loaded.
if ndims(img) > 2
  im = im2double(rgb2gray(img));
else
  im = im2double(img);
end

% gradient masks
% original = [-1 0 1];
% prewitt  = [-1 0 1; -1 0 1; -1 0 1];
% sobel    = [-1 0 1; -2 0 2; -1 0 1];
% roberts  = [0 1 1; -1 0 1; -1 -1 0];
dx = [-1 0 1];
dy = dx';

Ix = conv2(im, dx, 'same');
Iy = conv2(im, dy, 'same');

% for the gaussian smoothing around points.
% this is our window function
w_width = 5; % determines the effective size of the window
G = fspecial('gaussian', w_width, sigma);

% compute the harris corner matrix M at each point of the image.
A = conv2(Ix.^2, G, 'same');
B = conv2(Iy.^2, G, 'same');
C = conv2(Ix.*Iy, G, 'same');

det_M = (A.*B)-(C.^2);
tr_M = A + B;
R = det_M - (k * (tr_M.^2));

% Eliminate pixels around the border, since convolution does not produce
% valid values there
min_border = 20;
border = max(min_border, (1 + w_width)/2);
bordermask = zeros(size(R));
bordermask(border+1:end-border,border+1:end-border) = 1;

sze = 2*border + 1;
mx = ordfilt2(R, sze^2, ones(sze));

% find the corners
threshold = 0.001;
corners = (R > max(max(R)) * threshold) & (R == mx) & bordermask;

[ycoord xcoord] = find(corners);
corners = [xcoord ycoord];
